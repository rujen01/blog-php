<!DOCTYPE html> 
<html> 
    <head>    
    <title>Laravel Demo</title> 
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css"> </head> <body> <div class="container"> 
    <nav class="navbar navbar-inverse">    
    <div class="navbar-header">        
    <a class="navbar-brand" href="#">Laravel</a>    
    </div>    
    <ul class="nav navbar-nav">        
    <li><a href="<?php echo e(URL::to('batch')); ?>">View All Batch</a></li>        
    <li><a href="<?php echo e(URL::to('batch/create')); ?>">Create Batch</a>    
    </ul> </nav> 
    <h1>Edit <?php echo e($batch->name); ?></h1> 
 
<!-- if there are creation errors, they will show here --> <?php echo e(Html::ul($errors->all())); ?> 
 
<?php echo e(Form::model($batch, array('route' => array('batch.update', $batch->id), 'method' => 'PUT'))); ?> 
 
   <div class="form-group">        <?php echo e(Form::label('name', 'Name')); ?>        <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?> </div> 
 
   <?php echo e(Form::submit('Edit the Batch!', array('class' => 'btn btn-primary'))); ?> 
 
<?php echo e(Form::close()); ?> 
 
</div> 
</body> 
</html> 